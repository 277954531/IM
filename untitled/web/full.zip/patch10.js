function () {
    {
        //js怎么写？
    }
}