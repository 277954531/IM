define(function () {
    return {};
});